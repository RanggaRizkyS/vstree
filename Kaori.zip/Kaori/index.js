const Discord = require("discord.js");
const client = new Discord.Client;

const token = 'ODUyNDMxMDE1MTY2NDc2Mjg5.YMGuPw.FgrMRzPkWF54_mmy7hzwxCnYmdY';
var PREFIX = '!';
var version = '1.0.1';

const fs = require('fs');
const commands = new Discord.Collection();
const files = fs.readdirSync('commands').filter(file => file.endsWith('.js'));
for(const file of files) {
	const command = require(`./commands/${file}`);
	commands.set(command.name, command)
}

client.on('ready', () => {
  console.log('Bot Ready');
});

client.on('message', message => {
  let args = message.content.substring(PREFIX.length).split(' ');

client.on('guildMemberAdd', member => {
  const channel = member.guild.channels.cache.find(ch => ch.name === 'test');

  if (!channel)return;

  if (member.guild.id === 'Frown Store') {
    channel.send('Selamat Datang Ya Di Frown Store');
  }
});

  switch (args[0]) {
    case 'embed' :
      commands.get('embed').execute(message);
      break;
    case 'bot' :
      commands.get('bot').execute(client, message);
      break;
    case 'level' :
      commands.get('level').execute(client, message);
      break;
    case 'leveling' :
      commands.get('leveling').execute(client, message);
      break;
    case 'avatar' :
      commands.get('avatar').execute(client, message);
      break;
    case 'author' :
      commands.get('author').execute(client, message);
      break;
    case 'credits' :
      commands.get('credits').execute(client, message);
      break;
    case 'ping' :
      commands.get('ping').execute(client, message);
      break;
    case 'info' :
      commands.get('info').run(client, message);
      break;
    case 'version' :
      commands.get('version').run(client, message);
      break;
    case 'help' :
      commands.get('help').run(client, message);
      break;
    case 'uptime' :
      commands.get('uptime').execute(client, message);
      break;
    case 'more-kaori' :
      commands.get('morekaori').execute(message);
      break;
    case 'roles' :
      const channel = '844900057970769940';
      const yellowTeamRole = message.guild.roles.cache.find(role => role.name === "Client")

      const clientRole = '🍋';

      let reactionRole = new Discord.MessageEmbed()
        .setColor('1576d1')
        .setTitle('Kaori Discord Reaction Role')
        .setDescription('Choose a team!\n\n'
          + `${clientRole}`);

      message.channel.send(reactionRole);
      messageEmbed.react(clientRole);
      break;

  }
})

client.login(token);