const {
	MessageEmbed
} = require('discord.js');
module.exports = {
  name: "version",
  description: "Message Embed Version",
  async run (client, message) {
  	var versi = '2.5';
      var prefix = '!';
     const versionEmbed = new MessageEmbed()
     .setTitle('Kaori Discord Version')
     .setDescription('Kaori Version And Feature List')
     .setColor('1576d1')
     .addField('1.0.0', '> ping')
     .addField('2.0.0', '> ping\n> morekaori\n> kick')
     .addField('2.5.0', '> help\n> morekaori\n> kick\n> ping\n> info');
     await message.channel.send(versionEmbed);
  }
}