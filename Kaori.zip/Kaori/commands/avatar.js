const {
	MessageEmbed
} = require('discord.js');
module.exports = {
	name: 'avatar',
	description: 'avatar embed',
    execute(client, message) {
    	const user = message.mentions.users.first() || message.author;
        const avatarEmbed = new MessageEmbed()
        .setColor('1576d1')
        .setAuthor(`${user.username}'s Avatar`)
        .setImage(
        `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=256`
        );
        message.channel.send(avatarEmbed);
    }
}
      