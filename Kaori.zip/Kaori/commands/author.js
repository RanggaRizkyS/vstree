const {
	MessageEmbed
} = require('discord.js');
module.exports = {
	name: 'author',
	description: 'author embed',
    execute(client, message) {
    	const member = message.mentions.users.first();
    	const authorEmbed = new MessageEmbed()
        .setTitle('Author')
        .setColor('1576d1')
        .addField(`Ingfo :`, `> Sender Command: ${member}\n> Author: Meflems\n> Owner: FrownStore`)
        .setFooter('discord.paraverze.site');
        message.channel.send(authorEmbed);
    }
}
      