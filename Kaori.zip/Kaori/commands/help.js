const {
	MessageEmbed
} = require('discord.js');
module.exports = {
  name: "help",
  description: "Help Embed Message",
  async run (client, message) {
  	const lemon = '🍋';
      const marah = '😠';
      const batu = '🗿';
  
     const helpEmbed = new MessageEmbed()
     .setTitle('Kaori Discord Help')
     .setColor('1576d1')
     .setDescription('Kaori Discord Bot Its Bot Discord By Meflems, Kaori Using Discord.js\nThis Bot Support All Prefix, You Cant Use All Symbol')
     .addField('Commands', '> !info\n> !ping\n> !morekaori\n> !version\n> !uptime\n> !kick <@user>\n> !avatar\n> !author\n> !credits')
     .addField('Special Thanks To', '> ! Revand\n> otto\n> Lewken')
     .setFooter('discord.paraverze.site');
     let helpEmbed1 = await message.channel.send(helpEmbed);
     await helpEmbed1.react(lemon);
     await helpEmbed1.react(batu);
     await helpEmbed1.react(marah);
  }
}