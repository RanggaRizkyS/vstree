const {
	MessageEmbed
} = require('discord.js');
module.exports = {
	name: 'leveling',
	description: 'Leveling Embed',
    execute(client, message) {
    	const leveling = require('discord-leveling');
leveling.Fetch(UserID)
    }
}
      