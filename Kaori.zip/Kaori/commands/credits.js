const {
	MessageEmbed
} = require('discord.js');
module.exports = {
	name: 'credits',
	description: 'Credits Embed',
    execute(client, message) {
    	const creditEmbed = new MessageEmbed()
        .setTitle('Credits')
        .addField('Java Script', 'Discord.js')
        .addField('Developers', 'Meflems')
        .addField('Helper Code', 'Revand\nHorlando')
        .addField('Partnership', 'HStore\nRevStore')
        .setFooter('discord.paraverze.site')
        .setColor('1576d1');
        message.channel.send(creditEmbed);
    }
}
      