const {
	MessageEmbed
} = require('discord.js');
module.exports = {
	name: 'bot',
	description: 'bot embed',
    execute(client, message) {
    	const botEmbed = new MessageEmbed()
        .setTitle('Profile Bot')
        .setDescription('This Bot Using Discord.js')
        .addField('Hosting', '> Hosting Location: Singapure\n> Hosting RAM: 6GB\n> Hosting OS: Linux')
        .addField('Support', '> Revand\n> Horlando')
        .addField('Owner', 'Frown Store')
        .addField('Developer - Author', 'Meflems')
        .setColor('1576d1')
        .setThumbnail('https://cdn.discordapp.com/attachments/844900057970769940/855824027377860618/images_-_2021-06-19T215818.952.jpeg')
        .setFooter('discord.paraverze.site');
        message.channel.send(botEmbed);
    }
}
      