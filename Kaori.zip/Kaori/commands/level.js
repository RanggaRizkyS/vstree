const {
	MessageEmbed
} = require('discord.js');
module.exports = {
	name: 'level',
	description: 'Level Embed',
    execute(client, message) {
    	let score;
        if (message.guild) {
            score = client.getScore.get(message.author.id, message.guild.id);
            if (!score) {
                score = {
                    id: `${message.guild.id}-${message.author.id}`,
                    user: message.author.id,
                    guild: message.guild.id,
                    points: 0,
                    level: 1,
                };
            }
            const xpAdd = Math.floor(Math.random() * 10) + 50;
            const curxp = score.points;
            const curlvl = score.level;
            const nxtLvl = score.level * 5000;
            score.points = curxp + xpAdd;
            if (nxtLvl <= score.points) {
                score.level = curlvl + 1;
                const lvlup = new MessageEmbed()
                    .setAuthor(
                        `Congrats ${message.author.username}`,
                        message.author.displayAvatarURL()
                    )
                    .setTitle('You have leveled up!')
                    .setThumbnail('https://i.imgur.com/lXeBiMs.png')
                    .setColor(color)
                    .addField('New Level', curlvl + 1);
                message.channel.send(lvlup).then(msg => {
                    msg.delete({
                        timeout: 10000,
                    });
                });
            }
            client.setScore.run(score);
        }
    }
}
      