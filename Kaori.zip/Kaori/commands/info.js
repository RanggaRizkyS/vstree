const {
	MessageEmbed
} = require('discord.js');
module.exports = {
  name: "info",
  description: "Embed Messages Info",
  async run (client, message) {
  	const gay = '🏳️‍🌈';
      const like = '👍';
      const dislike = '👎';
      const photo = '📷';
      const frost_diamond = '😱';
      const alien = '👽';
      
     const infoEmbed = new MessageEmbed()
     .setTitle('Kaori Discord Info')
     .setColor('1576d1')
     .setDescription('This Bot Support All Prefix\nEXAMPLE: -info And More')
     .addField('Package', '> OS - Linux\n> JavaScript - Discord.js')
     .addField('Processor', '> RAM: 5798\n> Disk Space: 128 GB\n> CPU: Cualcom 2,02 GHz 8 Cores\n> Clock Speed CPU: 300 MHz')
     .addField('Network', '> IP: 192.168.10.10\n> Speed: 65 MBPS\n> Server Location: Indonesian/Jakarta')
     .setFooter('discord.paraverze.site');
    let infoEmbed1 = await message.channel.send(infoEmbed);
    await infoEmbed1.react(gay);
    await infoEmbed1.react(like);
    await infoEmbed1.react(dislike);
    await infoEmbed1.react(photo);
    await infoEmbed1.react(frost_diamond);
    await infoEmbed1.react(alien);
  }
}