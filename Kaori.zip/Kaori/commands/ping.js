const {
	MessageEmbed
} = require('discord.js');
module.exports = {
  name: "ping",
  description: "Get bot ping :/",
  execute (client, message) {
  	const start = Date.now()
      message.channel.send("ㅤ").then(message => {
  
      const end = Date.now()
      message.edit(`🏓: ${(end-start)}ms \n⏱️: ${client.ws.ping}ms`)
    })
  }
}