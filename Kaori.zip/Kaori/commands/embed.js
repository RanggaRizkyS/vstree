const {
	MessageEmbed
} = require('discord.js');
module.exports = {
	name: 'embed',
	description: 'this embed message',
    execute(message) {
		const embed = new MessageEmbed()
        .addField('Nama : ', 'Mepelems')
        .addField('Version : ', '1.0.0')
        .setThumbnail('https://cdn.discordapp.com/attachments/844900057970769940/852481784956715028/unknown.png')
        .setFooter('www.kaori.dc.paraverze.site', 'https://cdn.discordapp.com/attachments/844900057970769940/852481784956715028/unknown.png')
        .setTitle('Kaori Discord Bot')
        .setDescription('Kaori Adalah Bot Yang Di Buat Kusus Untuk Melayani Pembeli-Pembeli Di Frown Store https://discord.paraverze.site')
        .setColor('1576d1');
      message.channel.send(embed);
    }
}
      