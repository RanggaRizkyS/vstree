const {
	MessageEmbed
} = require('discord.js');
module.exports = {
	name: 'morekaori',
	description: 'this morekaori message',
    execute(message) {
   	const morekaoriEmbed = new MessageEmbed()
        .setColor('1576d1')
        .setTitle('Kaori Discord More-Bot')
        .setDescription('Kaori Its Bot By Meflems, My Prefix Its (!) Does Not Support All Prefix :x:')
        .setFooter('https://cdn.discordapp.com/attachments/844900057970769940/852481784956715028/unknown.png')
        .addField('This Bot Created In :', '5 Juni 2021')
        .addField('Developers Name :', 'Meflems/Rangga')
        .addField('Age Developer :', '12 :Orangelite:')
        .setThumbnail('https://cdn.discordapp.com/attachments/844900057970769940/852481784956715028/unknown.png')
      message.channel.send(morekaoriEmbed);
   }
}
      