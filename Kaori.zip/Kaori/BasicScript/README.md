git clone https://github.com/MefelemS/BasicScript
