Qclear
blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
echo
echo $green"Pilih Salah Satu!!"
echo
echo $blue"Mini"
echo $blue"Small"
echo $blue"Big"
echo
read -p "Mau Yang Mana : " font
read -p "Tulisan : " text

clear
toilet -f $font -F gay $text
echo $green"Done Bro"
sleep 10
sh ft.sh
